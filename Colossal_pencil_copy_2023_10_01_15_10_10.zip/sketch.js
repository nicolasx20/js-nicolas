function setup() {
  createCanvas(600, 600);
 background("grey");
}

function draw() {
  
  stroke("yellow");
  fill("beige");

  // console.log(mouseIsPressed);

  if (mouseIsPressed) {
    rect(mouseX, mouseY, 20, 35);
  }
}
